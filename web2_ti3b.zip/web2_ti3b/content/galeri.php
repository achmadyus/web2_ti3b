<div class="card">
    <h2>Galeri</h2>
    <form action="index.php?page=upload" method="POST" enctype="multipart/form-data">
        <label for="">Gambar</label>
        <input type="file" name="gambar" required>
        <button type="submit" class="submit">Upload</button>
    </form>
</div>