<div class="card">
    <h2>Home</h2>
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Doloremque tenetur, eaque natus quam rerum harum dolorum! Obcaecati tempora consequatur corrupti odit neque esse aliquam facilis asperiores placeat quam, soluta cum.
</div>