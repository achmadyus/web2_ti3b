<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="alert alert-info">
                    <center>
                    <br><br><br><br><br>
                    <b> SELAMAT DATANG DI WEBSITE SAYA KALAU MASUK LEPAS SENDALNYA</b>
                    <br><br><br><br>
                    <p>
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. 
                   Tempora sunt totam illo dicta! Neque perspiciatis quidem tenetur dolorem illo, 
                   odit nam et placeat nesciunt consequatur, ipsum cum nulla eligendi culpa.</p>
                   <br><br><br><br><br><br>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>